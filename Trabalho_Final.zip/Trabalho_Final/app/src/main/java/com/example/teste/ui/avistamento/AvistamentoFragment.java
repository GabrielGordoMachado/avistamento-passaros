package com.example.teste.ui.avistamento;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.teste.AppDatabase;
import com.example.teste.R;
import com.example.teste.databinding.FragmentAvistamentoBinding;
import com.example.teste.entity.Especie;
import com.example.teste.entity.QntdAvistamento;
import com.example.teste.entity.Usuario;
import com.example.teste.SessaoUsuario;

import android.media.MediaPlayer;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class AvistamentoFragment extends Fragment {

    private MediaPlayer mediaPlayer;

    private List<Especie> listaDeEspecies = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;

    private Spinner spinnerPassaro;
    private Button btnAvistamento;
    private TextView qtdAvistamento;
    private TextView nomeEspecie;
    private ImageView fotoPassaro;
    private FragmentAvistamentoBinding binding;
    private AvistamentoViewModel viewModel;
    private AppDatabase db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentAvistamentoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        viewModel = new ViewModelProvider(requireActivity()).get(AvistamentoViewModel.class);
        db = AppDatabase.getDatabase(getContext());

        spinnerPassaro = binding.passaro;
        btnAvistamento = binding.avistamento;
        qtdAvistamento = binding.qntAvistamento;
        nomeEspecie = binding.especie;
        fotoPassaro = binding.fotoPassaro;


        spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, new ArrayList<>());
        spinnerPassaro.setAdapter(spinnerAdapter);

        // Atualiza UI ao selecionar espécie
        spinnerPassaro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (listaDeEspecies.isEmpty() || position >= listaDeEspecies.size()) return;

                Especie especieSelecionada = listaDeEspecies.get(position);

                fotoPassaro.setImageURI(Uri.parse(especieSelecionada.getImagemUri()));
                nomeEspecie.setText("Espécie: " + especieSelecionada.getNomeEspecie());
                carregarQuantidade(especieSelecionada);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Tocar som ao clicar na imagem
        fotoPassaro.setOnClickListener(v -> {
            if (listaDeEspecies.isEmpty()) return;
            int position = spinnerPassaro.getSelectedItemPosition();
            if (position < 0 || position >= listaDeEspecies.size()) return;

            Especie especieSelecionada = listaDeEspecies.get(position);

            if (especieSelecionada.getSomRes() == 0) { // 0 = sem som (espécie customizada)
                Toast.makeText(getContext(), "Espécie sem som cadastrado.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (mediaPlayer != null) { mediaPlayer.release(); mediaPlayer = null; }
            mediaPlayer = MediaPlayer.create(getContext(), especieSelecionada.getSomRes());
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> { mp.release(); mediaPlayer = null; });
        });

        // Botão de adicionar avistamento
        btnAvistamento.setOnClickListener(v -> {
            if (listaDeEspecies.isEmpty()) return;
            int position = spinnerPassaro.getSelectedItemPosition();
            if (position < 0 || position >= listaDeEspecies.size()) return;

            if (!SessaoUsuario.estaLogado()) {
                Toast.makeText(getContext(), "Faça login para registrar avistamentos!", Toast.LENGTH_SHORT).show();
                return;
            }

            Especie especieSelecionada = listaDeEspecies.get(position);
            Usuario usuario = SessaoUsuario.getUsuario();

            Executors.newSingleThreadExecutor().execute(() -> {
                QntdAvistamento av = db.avistamentoDao().getAvistamento(usuario.getId(), especieSelecionada.getId());

                if (av == null) {
                    av = new QntdAvistamento(usuario.getId(), especieSelecionada.getId(), 1);
                    db.avistamentoDao().insert(av);
                } else {
                    av.setQuantidade(av.getQuantidade() + 1);
                    db.avistamentoDao().update(av);
                }

                final int quantidadeFinal = av.getQuantidade();

                // ✅ CORREÇÃO: Passa o ID da espécie, não a posição
                viewModel.setContador(especieSelecionada.getId(), quantidadeFinal);

                requireActivity().runOnUiThread(() -> qtdAvistamento.setText("Avistamentos: " + quantidadeFinal));
            });
        });

        return root;
    }

    private void carregarEspeciesDoBanco() {
        Executors.newSingleThreadExecutor().execute(() -> {
            listaDeEspecies = db.especieDao().getAll();

            List<String> nomesDasEspecies = new ArrayList<>();
            for (Especie e : listaDeEspecies) {
                nomesDasEspecies.add(e.getNomeEspecie());
            }

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    spinnerAdapter.clear();
                    spinnerAdapter.addAll(nomesDasEspecies);
                    spinnerAdapter.notifyDataSetChanged();
                });
            }
        });
    }


    private void carregarQuantidade(Especie especie) {
        if (!SessaoUsuario.estaLogado()) {
            qtdAvistamento.setText("Avistamentos: 0");
            return;
        }
        Usuario usuario = SessaoUsuario.getUsuario();

        Executors.newSingleThreadExecutor().execute(() -> {
            QntdAvistamento av = db.avistamentoDao().getAvistamento(usuario.getId(), especie.getId());

            final int quantidadeFinal = (av != null) ? av.getQuantidade() : 0;

            // ✅ CORREÇÃO: Passa o ID da espécie, não a posição
            viewModel.setContador(especie.getId(), quantidadeFinal);

            requireActivity().runOnUiThread(() -> qtdAvistamento.setText("Avistamentos: " + quantidadeFinal));
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        carregarEspeciesDoBanco();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        binding = null;
    }
}