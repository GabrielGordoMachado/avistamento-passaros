package com.example.teste.ui.avistamento;

import androidx.lifecycle.ViewModel;

// ✅ Imports adicionados
import java.util.HashMap;
import java.util.Map;

public class AvistamentoViewModel extends ViewModel {

    // ✅ CORREÇÃO: Trocado array por Map para suportar espécies ilimitadas.
    // A chave (Integer) é o ID da espécie, o Valor (Integer) é a quantidade.
    private Map<Integer, Integer> contadores = new HashMap<>();

    // ✅ CORREÇÃO: Método agora usa 'especieId' em vez de 'position'
    public int getContador(int especieId) {
        Integer total = contadores.get(especieId);
        // Se não houver entrada no map, retorna 0
        return (total != null) ? total : 0;
    }

    public Map<Integer, Integer> getContadores() {
        return contadores;
    }

    // ✅ CORREÇÃO: Método agora usa 'especieId' em vez de 'position'
    public void setContador(int especieId, int total) {
        contadores.put(especieId, total);
    }

    // O método incrementar(pos) não é mais usado no seu código,
    // mas se fosse, também deveria ser alterado para usar especieId.
}