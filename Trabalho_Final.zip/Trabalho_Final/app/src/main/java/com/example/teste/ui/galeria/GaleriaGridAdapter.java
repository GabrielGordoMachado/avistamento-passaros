package com.example.teste.ui.galeria;

import android.content.Context;
import android.net.Uri; // Importar
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.teste.R;
import com.example.teste.entity.Especie; // Importar

import java.util.ArrayList; // Importar
import java.util.List; // Importar

// ✅ CORREÇÃO: Modificado para aceitar List<Especie>
public class GaleriaGridAdapter extends BaseAdapter {

    private Context context;
    private List<Especie> especies;

    public GaleriaGridAdapter(Context context, List<Especie> especies) {
        this.context = context;
        this.especies = (especies != null) ? especies : new ArrayList<>();
    }

    @Override
    public int getCount() {
        return especies.size();
    }

    @Override
    public Object getItem(int position) {
        return especies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return especies.get(position).getId(); // Usa o ID real
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.galeria_grid_item, parent, false);
        } else {
            view = convertView;
        }

        ImageView imageView = view.findViewById(R.id.galeriaImagem);
        TextView textView = view.findViewById(R.id.galeriaNome);

        Especie especie = especies.get(position);

        // ✅ CORREÇÃO: Carrega a imagem pela URI
        if (especie.getImagemUri() != null && !especie.getImagemUri().isEmpty()) {
            imageView.setImageURI(Uri.parse(especie.getImagemUri()));
        } else {
            // Imagem padrão caso a URI esteja vazia
            imageView.setImageResource(R.mipmap.ic_launcher);
        }

        textView.setText(especie.getNomeEspecie());
        return view;
    }

    // Método auxiliar para atualizar a lista do adapter
    public void setEspecies(List<Especie> novasEspecies) {
        this.especies.clear();
        if (novasEspecies != null) {
            this.especies.addAll(novasEspecies);
        }
        notifyDataSetChanged(); // Notifica o GridView para atualizar
    }
}