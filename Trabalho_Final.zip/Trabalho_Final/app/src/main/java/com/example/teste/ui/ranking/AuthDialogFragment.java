package com.example.teste.ui.ranking;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.teste.AppDatabase;
import com.example.teste.R;
import com.example.teste.SessaoUsuario;
import com.example.teste.entity.Usuario;
import com.example.teste.hash.HasherSenha;

import java.util.concurrent.Executors;

public class AuthDialogFragment extends DialogFragment {

    private static final String ARG_IS_LOGIN = "is_login";
    private boolean isLoginMode; // true = Login, false = Cadastro
    private OnAuthListener authListener;

    public interface OnAuthListener {
        void onAuthSuccess(Usuario usuario);
    }

    public void setOnAuthListener(OnAuthListener listener) {
        this.authListener = listener;
    }

    // Método fábrica para criar o dialog com o modo correto
    public static AuthDialogFragment newInstance(boolean isLogin) {
        AuthDialogFragment frag = new AuthDialogFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_IS_LOGIN, isLogin);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            isLoginMode = getArguments().getBoolean(ARG_IS_LOGIN);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Context context = requireContext();
        // Usa o layout que você já criou (fragment_cadastro.xml)
        View view = LayoutInflater.from(context).inflate(R.layout.fragment_cadastro, null);

        TextView titulo = view.findViewById(R.id.CadastroTitulo);
        EditText inputNome = view.findViewById(R.id.inputNome);
        EditText inputEmail = view.findViewById(R.id.inputEmail);
        EditText inputSenha = view.findViewById(R.id.inputSenha);
        Button btnConfirmar = view.findViewById(R.id.btnEntrar);
        Button btnCancelar = view.findViewById(R.id.btnCancelar);

        // --- Configura Visual (Login vs Cadastro) ---
        if (isLoginMode) {
            titulo.setText("Login");
            inputNome.setVisibility(View.GONE); // Esconde nome no login
            btnConfirmar.setText("Entrar");
        } else {
            titulo.setText("Cadastro");
            inputNome.setVisibility(View.VISIBLE); // Mostra nome no cadastro
            btnConfirmar.setText("Cadastrar");
        }

        btnCancelar.setOnClickListener(v -> dismiss());

        btnConfirmar.setOnClickListener(v -> {
            String nome = inputNome.getText().toString().trim();
            String email = inputEmail.getText().toString().trim();
            String senha = inputSenha.getText().toString().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(context, "Preencha e-mail e senha!", Toast.LENGTH_SHORT).show();
                return;
            }

            // No cadastro, nome é obrigatório
            if (!isLoginMode && nome.isEmpty()) {
                Toast.makeText(context, "Preencha o nome!", Toast.LENGTH_SHORT).show();
                return;
            }

            processarAutenticacao(context, nome, email, senha);
        });

        return new AlertDialog.Builder(context)
                .setView(view)
                .setCancelable(false)
                .create();
    }

    private void processarAutenticacao(Context context, String nome, String email, String senha) {
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.getDatabase(context);
            Usuario usuarioExistente = db.usuarioDao().findByEmail(email);

            if (isLoginMode) {
                // --- LÓGICA DE LOGIN ---
                if (usuarioExistente != null) {
                    // Verifica senha usando o Hasher
                    boolean senhaValida = HasherSenha.verificarSenha(senha, usuarioExistente.getSenha());

                    if (senhaValida) {
                        finalizarSucesso(context, usuarioExistente, "Login realizado com sucesso!");
                    } else {
                        mostrarToast(context, "Senha incorreta.");
                    }
                } else {
                    mostrarToast(context, "E-mail não encontrado.");
                }

            } else {
                // --- LÓGICA DE CADASTRO ---
                if (usuarioExistente != null) {
                    mostrarToast(context, "Este e-mail já está em uso.");
                } else {
                    // 1. Gera o Hash da senha
                    String senhaHash = HasherSenha.gerarHash(senha);

                    // 2. Cria usuário com o Hash
                    Usuario novoUsuario = new Usuario(nome, email, senhaHash);
                    long id = db.usuarioDao().insert(novoUsuario);
                    novoUsuario.setId((int) id);

                    // 3. Inicializa tabelas auxiliares
                    db.inicializarAvistamentosParaUsuario(novoUsuario);

                    finalizarSucesso(context, novoUsuario, "Cadastro realizado com sucesso!");
                }
            }
        });
    }

    private void finalizarSucesso(Context context, Usuario usuario, String msg) {
        // Salva na sessão
        SessaoUsuario.salvarSessao(context, usuario);

        // Atualiza UI na thread principal
        requireActivity().runOnUiThread(() -> {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
            if (authListener != null) {
                authListener.onAuthSuccess(usuario);
            }
            dismiss();
        });
    }

    private void mostrarToast(Context context, String msg) {
        requireActivity().runOnUiThread(() ->
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show());
    }
}