package com.example.teste.ui.galeria;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.teste.AppDatabase;
import com.example.teste.R;
import com.example.teste.entity.Especie; // Importar

import java.util.ArrayList; // Importar
import java.util.List; // Importar
import java.util.concurrent.Executors; // Importar

public class GaleriaFragment extends Fragment {
    private AppDatabase db;
    private GridView gridView;
    private GaleriaGridAdapter adapter;
    private List<Especie> listaDeEspecies = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        db = AppDatabase.getDatabase(getContext());
        return inflater.inflate(R.layout.fragment_galeria, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        gridView = view.findViewById(R.id.gridGaleria);

        // ✅ CORREÇÃO: Inicializa o adapter com uma lista vazia
        adapter = new GaleriaGridAdapter(requireContext(), listaDeEspecies);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener((parent, v, position, id) -> {
            Especie especieClicada = listaDeEspecies.get(position);
            Toast.makeText(requireContext(),
                    "Espécie: " + especieClicada.getNomeEspecie(),
                    Toast.LENGTH_SHORT).show();
        });

        Button btnAdd = view.findViewById(R.id.button_adicionarEspecie);
        btnAdd.setOnClickListener(v -> {
            criarEspecieDialogFragment criarDialog = new criarEspecieDialogFragment();
            criarDialog.show(getParentFragmentManager(), "criarEspecie");
        });
    }

    private void carregarEspeciesDoBanco() {
        Executors.newSingleThreadExecutor().execute(() -> {
            // Atualiza a lista interna
            listaDeEspecies = db.especieDao().getAll();

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    // Atualiza o adapter na Main Thread
                    adapter.setEspecies(listaDeEspecies);
                });
            }
        });
    }

    // ✅ CORREÇÃO: Recarrega a galeria sempre que o fragmento se torna visível
    // Isso garante que novas espécies apareçam após serem criadas.
    @Override
    public void onResume() {
        super.onResume();
        carregarEspeciesDoBanco();
    }
}