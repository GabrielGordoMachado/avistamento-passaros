package com.example.teste.ui.ranking;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.teste.AppDatabase;
import com.example.teste.R;
import com.example.teste.SessaoUsuario;
import com.example.teste.entity.QntdAvistamento;
import com.example.teste.entity.Usuario;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;

public class RankingFragment extends Fragment {

    private ListView rankingListView;
    private Button btnAddUser; // Botão de Cadastro
    private Button btnLoginUser; // Botão de Login
    private AppDatabase db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_ranking, container, false);
        rankingListView = root.findViewById(R.id.rankingListView);
        btnAddUser = root.findViewById(R.id.btnCadastro);
        btnLoginUser = root.findViewById(R.id.btnLogin);

        db = AppDatabase.getDatabase(requireContext());

        // Configura botões iniciais
        atualizarInterface();
        atualizarRankingTodosUsuarios();

        // Clique no botão CADASTRO
        btnAddUser.setOnClickListener(v -> {
            // false = Modo Cadastro (Mostra campo nome)
            abrirDialogAuth(false);
        });

        // Clique no botão LOGIN / DESLOGAR
        btnLoginUser.setOnClickListener(v -> {
            if (SessaoUsuario.estaLogado()) {
                // Se já logado, desloga
                SessaoUsuario.deslogar(requireContext());
                atualizarInterface();
            } else {
                // Se não logado, abre login
                // true = Modo Login (Esconde campo nome)
                abrirDialogAuth(true);
            }
        });

        return root;
    }

    private void abrirDialogAuth(boolean isLogin) {
        AuthDialogFragment dialog = AuthDialogFragment.newInstance(isLogin);
        dialog.setCancelable(false);

        // Callback executado quando o usuário termina o login/cadastro com sucesso
        dialog.setOnAuthListener(usuario -> {
            atualizarInterface();
            atualizarRankingTodosUsuarios();
        });

        dialog.show(getParentFragmentManager(), isLogin ? "login" : "cadastro");
    }

    // Atualiza visibilidade e texto dos botões
    public void atualizarInterface() {
        if (SessaoUsuario.estaLogado()) {
            btnLoginUser.setText("Deslogar");
            btnAddUser.setVisibility(View.GONE);
        } else {
            btnLoginUser.setText("Fazer Login");
            btnAddUser.setVisibility(View.VISIBLE);
        }
    }

    // Lógica do Ranking (mantida igual)
    public void atualizarRankingTodosUsuarios() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Usuario> usuarios = db.usuarioDao().getAllUsuarios();
            List<UsuarioRanking> ranking = new ArrayList<>();

            for (Usuario u : usuarios) {
                List<QntdAvistamento> avistamentos = db.avistamentoDao().getByUsuario(u.getId());
                int totalAvistamentos = 0;
                for (QntdAvistamento a : avistamentos) {
                    totalAvistamentos += a.getQuantidade();
                }
                ranking.add(new UsuarioRanking(u.getNome(), totalAvistamentos));
            }

            // Ordena decrescente
            Collections.sort(ranking, (a, b) -> b.total - a.total);

            List<String> rankingStrings = new ArrayList<>();
            for (UsuarioRanking ur : ranking) {
                rankingStrings.add(ur.nome + " - " + ur.total + " avistamentos");
            }

            // Atualiza UI
            requireActivity().runOnUiThread(() -> {
                if (getContext() != null) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                            android.R.layout.simple_list_item_1, rankingStrings);
                    rankingListView.setAdapter(adapter);
                }
            });
        });
    }

    private static class UsuarioRanking {
        String nome;
        int total;
        UsuarioRanking(String nome, int total) {
            this.nome = nome;
            this.total = total;
        }
    }
}