package com.example.teste.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import com.example.teste.entity.Especie;
import java.util.List;

@Dao
public interface EspecieDao {
    @Insert
    void insert(Especie especie);

    @Query("SELECT * FROM Especie")
    List<Especie> getAll();

    @Query("SELECT COUNT(*) FROM Especie")
    int count();
}