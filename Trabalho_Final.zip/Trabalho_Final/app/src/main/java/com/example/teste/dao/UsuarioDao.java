package com.example.teste.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.teste.entity.Usuario;

import java.util.List;

@Dao
public interface UsuarioDao {

    @Insert
    long insert(Usuario usuario); // agora retorna o ID gerado

    @Query("SELECT * FROM usuario WHERE email = :email LIMIT 1")
    Usuario findByEmail(String email);

    @Query("SELECT * FROM usuario")
    List<Usuario> getAllUsuarios();

}