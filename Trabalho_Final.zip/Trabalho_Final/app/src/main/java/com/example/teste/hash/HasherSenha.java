package com.example.teste.hash;

import android.util.Base64;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class HasherSenha {

    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 10000; // Número de iterações
    private static final int KEY_LENGTH = 256;   // Tamanho da chave em bits

    /**
     * Gera um hash seguro (Salt + Hash) para salvar no banco.
     */
    public static String gerarHash(String senha) {
        try {
            // 1. Gerar Salt aleatório
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);

            // 2. Gerar Hash
            byte[] hash = pbkdf2(senha.toCharArray(), salt);

            // 3. Retornar string combinada (Salt:Hash)
            return Base64.encodeToString(salt, Base64.NO_WRAP) + ":" +
                    Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar hash da senha", e);
        }
    }

    /**
     * Verifica se a senha digitada bate com o hash salvo no banco.
     */
    public static boolean verificarSenha(String senhaDigitada, String hashArmazenado) {
        try {
            // 1. Separar Salt e Hash
            String[] partes = hashArmazenado.split(":");
            if (partes.length != 2) return false;

            byte[] saltOriginal = Base64.decode(partes[0], Base64.NO_WRAP);
            byte[] hashOriginal = Base64.decode(partes[1], Base64.NO_WRAP);

            // 2. Recalcular hash com o mesmo salt
            byte[] hashCalculado = pbkdf2(senhaDigitada.toCharArray(), saltOriginal);

            // 3. Comparar
            return Arrays.equals(hashOriginal, hashCalculado);

        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] pbkdf2(char[] password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH);
        SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITHM);
        return skf.generateSecret(spec).getEncoded();
    }
}