package com.example.teste.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Especie {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nomeEspecie;

    // ✅ CORREÇÃO: Padronizado para salvar apenas a URI como String
    private String imagemUri;

    private int somRes; // ID do recurso R.raw

    public Especie(String nomeEspecie, String imagemUri, int somRes) {
        this.nomeEspecie = nomeEspecie;
        this.imagemUri = imagemUri;
        this.somRes = somRes;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }
    public String getNomeEspecie() { return nomeEspecie; }
    public void setNomeEspecie(String nomeEspecie) { this.nomeEspecie = nomeEspecie; }

    // ✅ Getter e Setter atualizados
    public String getImagemUri() { return imagemUri; }
    public void setImagemUri(String imagemUri) { this.imagemUri = imagemUri; }

    public int getSomRes() { return somRes; }
    public void setSomRes(int somRes) { this.somRes = somRes; }
}