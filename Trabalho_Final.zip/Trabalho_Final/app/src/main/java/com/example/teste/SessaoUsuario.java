package com.example.teste;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.teste.entity.Usuario;

public class SessaoUsuario {
    private static final String PREFS_NAME = "sessao_usuario";
    private static final String KEY_EMAIL = "email";
    private static Usuario usuarioLogado;

    public static void salvarSessao(Context context, Usuario usuario) {
        usuarioLogado = usuario;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_EMAIL, usuario.getEmail()).apply();
    }

    public static void carregarSessao(Context context) {
        if (usuarioLogado == null) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String email = prefs.getString(KEY_EMAIL, null);
            if (email != null) {
                AppDatabase db = AppDatabase.getDatabase(context);
                usuarioLogado = db.usuarioDao().findByEmail(email);
            }
        }
    }

    public static boolean estaLogado() {
        return usuarioLogado != null;
    }

    public static Usuario getUsuario() {
        return usuarioLogado;
    }

    public static void deslogar(Context context) {
        usuarioLogado = null;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
    }
}