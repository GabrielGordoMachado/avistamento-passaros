package com.example.teste;

import android.os.Bundle;

import com.example.teste.ui.ranking.AuthDialogFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.teste.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load user session in background thread
        new Thread(() -> {
            SessaoUsuario.carregarSessao(this);

            if (!SessaoUsuario.estaLogado()) {
                runOnUiThread(() -> {
                    AuthDialogFragment loginDialog = new AuthDialogFragment();
                    loginDialog.setCancelable(false);
                    loginDialog.show(getSupportFragmentManager(), "login");
                });
            }
        }).start();

        // Setup bottom navigation
        BottomNavigationView navView = binding.navView;
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_galeria,
                R.id.navigation_avistamento,
                R.id.navigation_ranking
        ).build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
    }
}