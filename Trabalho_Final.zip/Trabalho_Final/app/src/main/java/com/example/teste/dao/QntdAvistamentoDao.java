package com.example.teste.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.teste.entity.QntdAvistamento;
import java.util.List;

@Dao
public interface QntdAvistamentoDao {
    @Insert
    void insert(QntdAvistamento qntdAvistamento);

    @Query("SELECT * FROM qntdavistamento WHERE usuarioId = :usuarioId")
    List<QntdAvistamento> getByUsuario(int usuarioId);

    @Query("SELECT * FROM qntdavistamento WHERE especieId = :especieId")
    List<QntdAvistamento> getByEspecie(int especieId);

    @Query("SELECT quantidade FROM qntdavistamento WHERE usuarioId = :usuarioId AND especieId = :especieId LIMIT 1")
    int getQuantidade(int usuarioId, int especieId);

    @Query("UPDATE qntdavistamento SET quantidade = :qtd WHERE usuarioId = :usuarioId AND especieId = :especieId")
    void updateQuantidade(int usuarioId, int especieId, int qtd);

    @Query("SELECT * FROM qntdavistamento WHERE usuarioId = :usuarioId AND especieId = :especieId LIMIT 1")
    QntdAvistamento getAvistamento(int usuarioId, int especieId);

    @Update
    void update(QntdAvistamento av);
}