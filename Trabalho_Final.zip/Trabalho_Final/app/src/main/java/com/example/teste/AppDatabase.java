package com.example.teste;

import android.content.Context;
import android.net.Uri; // Importado

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.teste.dao.*;
import com.example.teste.entity.*;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Usuario.class, Especie.class, QntdAvistamento.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UsuarioDao usuarioDao();
    public abstract EspecieDao especieDao();
    public abstract QntdAvistamentoDao avistamentoDao();

    private static volatile AppDatabase INSTANCE;
    private static final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "bird_db")
                            .fallbackToDestructiveMigration()
                            .addCallback(new PrepopulateCallback(context.getApplicationContext()))
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Classe interna para pré-popular o banco de dados
    private static class PrepopulateCallback extends RoomDatabase.Callback {
        private final Context context;

        PrepopulateCallback(Context context) {
            this.context = context;
        }

        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            dbExecutor.execute(() -> {
                AppDatabase database = INSTANCE;
                if (database != null) {
                    EspecieDao especieDao = database.especieDao();

                    String[] nomesImagens = {
                            "bem_te_vi", "canario_da_terra", "cardeal", "curio",
                            "joao_de_barro", "sabia_laranjeira"
                    };
                    String[] nomesSons = {
                            "bem_te_vi", "canario_da_terra", "cardeal", "curio",
                            "joao_de_barro", "sabia_laranjeira"
                    };
                    String[] nomesExibicao = {
                            "Bem-te-vi", "Canário-da-terra", "Cardeal", "Curió",
                            "João-de-barro", "Sabiá-laranjeira"
                    };

                    for (int i = 0; i < nomesExibicao.length; i++) {
                        int imageResId = context.getResources().getIdentifier(nomesImagens[i], "drawable", context.getPackageName());
                        int soundResId = context.getResources().getIdentifier(nomesSons[i], "raw", context.getPackageName());

                        if (imageResId != 0 && soundResId != 0) {

                            // Constrói a URI do recurso
                            String imagemUriString = new Uri.Builder()
                                    .scheme("android.resource")
                                    .authority(context.getPackageName())
                                    .appendPath(String.valueOf(imageResId))
                                    .build().toString();

                            especieDao.insert(new Especie(
                                    nomesExibicao[i],
                                    imagemUriString, // Salva a URI
                                    soundResId
                            ));
                        }
                    }
                }
            });
        }
    }

    public void inicializarAvistamentosParaUsuario(Usuario usuario) {
        dbExecutor.execute(() -> {
            EspecieDao especieDao = especieDao();
            QntdAvistamentoDao avistamentoDao = avistamentoDao();

            for (Especie e : especieDao.getAll()) {
                // Verifica se já existe antes de inserir
                if (avistamentoDao.getAvistamento(usuario.getId(), e.getId()) == null) {
                    QntdAvistamento a = new QntdAvistamento(usuario.getId(), e.getId(), 0);
                    avistamentoDao.insert(a);
                }
            }
        });
    }
}