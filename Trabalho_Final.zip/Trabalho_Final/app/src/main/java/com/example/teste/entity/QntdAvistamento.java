package com.example.teste.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        primaryKeys = {"usuarioId", "especieId"},
        foreignKeys = {
                @ForeignKey(entity = Usuario.class,
                        parentColumns = "id",
                        childColumns = "usuarioId",
                        onDelete = ForeignKey.CASCADE),
                @ForeignKey(entity = Especie.class,
                        parentColumns = "id",
                        childColumns = "especieId",
                        onDelete = ForeignKey.CASCADE)
        }
)
public class QntdAvistamento {
    private int usuarioId;
    private int especieId;
    private int quantidade;

    public QntdAvistamento(int usuarioId, int especieId, int quantidade) {
        this.usuarioId = usuarioId;
        this.especieId = especieId;
        this.quantidade = quantidade;
    }

    public int getUsuarioId() { return usuarioId; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }

    public int getEspecieId() { return especieId; }
    public void setEspecieId(int especieId) { this.especieId = especieId; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
}