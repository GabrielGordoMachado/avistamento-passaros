package com.example.teste.ui.galeria;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;

import com.example.teste.AppDatabase;
import com.example.teste.R;
import com.example.teste.entity.Especie;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale; // Importar Locale
import java.util.concurrent.Executors;

public class criarEspecieDialogFragment extends DialogFragment {

    private static final int REQ_GALERIA = 101;
    private static final int REQ_CAMERA = 102;

    private EditText inputNome;
    private Button btnSelecionarImagem, btnTirarFoto, btnConfirmar;
    private ImageView imgPreview;
    private Uri imagemUri;
    private AppDatabase db;
    private String caminhoFotoAtual;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_criar_especie, container, false);

        inputNome = view.findViewById(R.id.inputNomeEspecie);
        btnSelecionarImagem = view.findViewById(R.id.btnSelecionarImagem);
        btnTirarFoto = view.findViewById(R.id.btnTirarFoto);
        btnConfirmar = view.findViewById(R.id.btnConfirmar);
        imgPreview = view.findViewById(R.id.imgPreview);
        db = AppDatabase.getDatabase(requireContext());

        // Escolher imagem da galeria
        btnSelecionarImagem.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQ_GALERIA);
        });

        // Tirar foto com a câmera
        btnTirarFoto.setOnClickListener(v -> abrirCamera());

        // Confirmar criação da espécie
        btnConfirmar.setOnClickListener(v -> confirmarCriacao());

        return view;
    }

    private void abrirCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
            try {
                File fotoFile = criarArquivoImagem();
                if (fotoFile != null) {
                    imagemUri = FileProvider.getUriForFile(requireContext(),
                            // Certifique-se que seu Manifest e filepaths.xml estão configurados
                            // com este mesmo authority (normalmente o package name + .fileprovider)
                            requireContext().getPackageName() + ".fileprovider",
                            fotoFile);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imagemUri);
                    startActivityForResult(intent, REQ_CAMERA);
                }
            } catch (IOException e) {
                Toast.makeText(getContext(), "Erro ao criar arquivo de imagem", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private File criarArquivoImagem() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String nomeArquivo = "JPEG_" + timeStamp + "_";
        File dir = requireActivity().getExternalFilesDir(null); // Armazenamento privado do app
        File imagem = File.createTempFile(nomeArquivo, ".jpg", dir);
        caminhoFotoAtual = imagem.getAbsolutePath();
        return imagem;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQ_GALERIA && data != null) {
                imagemUri = data.getData();
                imgPreview.setImageURI(imagemUri);
            } else if (requestCode == REQ_CAMERA && imagemUri != null) {
                // A imagemUri já foi definida em 'abrirCamera()'
                imgPreview.setImageURI(imagemUri);
            }
        }
    }

    private void confirmarCriacao() {
        String nome = inputNome.getText().toString().trim();
        if (nome.isEmpty() || imagemUri == null) {
            Toast.makeText(getContext(), "Preencha o nome e selecione uma imagem", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            // Salva no banco (usa URI da imagem como string e 0 para som)
            db.especieDao().insert(new Especie(nome, imagemUri.toString(), 0));

            requireActivity().runOnUiThread(() -> {
                Toast.makeText(getContext(), "Espécie criada com sucesso!", Toast.LENGTH_SHORT).show();
                dismiss();
            });
        });
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        // O GaleriaFragment (no onResume) vai recarregar a lista
    }
}